HyperImage Reader version 3X, which includes a new design and functions on mobile and tablets. The HyperImage Reader is used to publish projects compiled with the HyperImage Editor.
 
13-August-2015

The in­no­va­ti­ve re­se­arch en­vi­ron­ment al­lows any num­ber of de­tails, or sub­re­gi­ons, wi­t­hin an image to be high­ligh­ted and de­scri­bed. It links an­no­ta­ti­ons wi­t­hin a cor­pus to each other, ma­king them ac­ces­si­ble in in­di­ces. In­te­rim re­sults as well as fi­nal ver­si­ons can be com­pi­led at any time as an on­line/​off­line hy­per­me­dia pu­bli­ca­ti­on.

For more information see the HyperImage project on Leuphana (http://www.leuphana.de/institute/icam/forschung-projekte/hyperimage.html)

In order to use the new design with HyperImage projects, you will need to download and add these finals to any post petal export from the HyperImage Editor. 

To add to HyperImage projects that already include the HI Reader, you can do the following: 

1. replace the index.html file in your HyperImage project with the one included in this repository
2. replace the reader folder in your HyperImage project with the one included in this repository
3. Add the fonts folder included in this repository to the top leve directory of your HyperImage project folder 
4. Pubish to a server or CD-Rom as normal 


